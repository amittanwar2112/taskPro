import './App.css';
import  Navbars from './Layout/navbar'
import   Mainlogic from './Mainlogic/Mainlogic'

function App() {
  return (
    <div >
        <Navbars></Navbars>
        <Mainlogic></Mainlogic>
    </div>
  );
}

export default App;
