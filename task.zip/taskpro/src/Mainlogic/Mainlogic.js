import React, { Component } from 'react'
import   Layout from '../Layout/Layout'

import axios from 'axios'

class Mainlogic extends Component {
    constructor(props) {
        super(props);
        this.recipelist="";
        this.price ="";
        this.state ={
            nameObject:{},
            titileObject :{}
        }
      }
      /*
      orrdernow = (event) => {
        console.log(event.target.value);
        this.price= event.target.value;
        this.setState({paymentcheck : true});
    }    
    */
    componentDidMount = () => {
        
        axios.get('https://test-54720.firebaseio.com/.json?print=pretty').then(response =>{
           
            let Data =  response.data;
            //console.log(Data);
            let users=Data.users;
            let accounts=Data.accounts;
            let object={};
            let object1={};
     
              for ( let i in accounts){

                for(let j in users){
                  if(i === users[j].account){
                    object[i]= users[j].name
                  
                  }
                  
                } 
              }
              for ( let i in accounts){
                //console.log(i.apps);
                object1[i] =  accounts[i].apps;
 
              }
              //object = {...object1} 
              /*
              for ( let k in object){
                //console.log(i.apps);
                object[k] =  object1[k];
 
              }
              */
              console.log(object);

              this.setState({nameObject : object});
              this.setState({titileObject : object1});

        });

    }  
  render() {

    return (
        <div>
          <Layout
          NameObject = {this.state.nameObject}
          TitleObject = {this.state.titileObject}
          ></Layout>
        </div>
    )
  }
}

export default Mainlogic