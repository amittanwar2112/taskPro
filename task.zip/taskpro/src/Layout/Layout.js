import React from 'react'
import {Card,Button} from 'react-bootstrap'
import 'bootstrap/dist/css/bootstrap.min.css';
import './layout.css';

function Layout(props) {
    let card1=[];

    
    if((Object.keys(props.NameObject).length >=0) && (Object.keys(props.TitleObject).length >=0) ){
        console.log("inside");
        console.log(props.NameObject);
        console.log(props.TitleObject);
         let titlearray={};
        let dataArray={...props.NameObject};
        for(let i in props.TitleObject){
          //console.log(Object.keys(props.TitleObject[i]));
          let keys = Object.keys(props.TitleObject[i])
          //console.log(props.TitleObject[i].keys);
          titlearray[i] = props.TitleObject[i][keys].title;
        }
        console.log(titlearray);

        
        
        //console.log(props.dataarray);
        let imgurl="";
        for(let i in  titlearray){
            //imgurl= dataArray[i].image
            card1.push(
                <Card key={i} className="item" style={{textAlign:"center",height:"200px",backgroundColor:"#b3ffff"}}>
                    <p style={{fontWeight: "bold",fontSize:"30px"}}>User : {props.NameObject[i]}</p>
                    <p>Account ID : {i}</p>
                    <p>Title : {titlearray[i]}</p>
                </Card>
            );
        }
        
    }
    
  return (
    <div className={`container`}>
      {card1}
    </div>
  )
}

export default Layout